from django.contrib.auth import login, authenticate
from rest_framework import status
from rest_framework.authentication import TokenAuthentication
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from .models import CustomUser, Teacher, Course, Student
from .serializers import UsersSerializer, TeachersSerializer, CourseSerializer, StudentsSerializer, \
    SaveTeachersSerializer, SaveStudentSerializer


class UsersAPIView(APIView):
    def get(self, request):
        users = CustomUser.objects.all()
        serializer = UsersSerializer(users, many=True)
        return Response(data=serializer.data)


class StudentCoursesAPIView(APIView):
    def get(self, request, pk):
        courses = Course.objects.filter(student__user__pk=pk)
        serializer = CourseSerializer(courses, many=True)
        return Response(data=serializer.data)


class TeacherCoursesAPIView(APIView):
    def get(self, request, pk):
        teacher = Teacher.objects.get(user__pk=pk)
        serializer = TeachersSerializer(teacher)
        return Response(data=serializer.data)


class TeachersUnApproveAPIView(APIView):
    def get(self, request):
        teachers = Teacher.objects.filter(is_approve=True).filter(is_active=False)
        serializer = TeachersSerializer(teachers, many=True)
        return Response(data=serializer.data)


class TeachersViewSet(ModelViewSet):
    queryset = Teacher.objects.all()
    authentication_classes = (TokenAuthentication,)
    serializer_class = TeachersSerializer


class TeacherSaveViewSet(ModelViewSet):
    queryset = Teacher.objects.all()
    serializer_class = SaveTeachersSerializer


class StudentsViewSet(ModelViewSet):
    queryset = Student.objects.all()
    authentication_classes = (TokenAuthentication,)
    serializer_class = StudentsSerializer


class StudentSaveViewSet(ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = SaveStudentSerializer


class CustomAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'is_superuser': user.is_superuser,
            'is_teacher': user.is_teacher,
            'is_student': user.is_student
        })
